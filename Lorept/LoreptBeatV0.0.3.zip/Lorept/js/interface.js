function load(){
	var LadName = document.getElementById("ld").value;
	document.getElementById("scrpit").innerHTML='<script src="../js/Extend/'+LadName+'.js"></script>';
	setTimeout(function(){ document.getElementById("scrpit").innerHTML=vers }, 5000);
	ms()
	return 1;
}
function ms(){
	var o = 1
	if (load() === o){
		console.log("信息:成功导入扩展包")
	}else{
		console.log("错误:扩展包导入失败")
	}
}