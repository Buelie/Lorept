function ver(){
	var vers = "0.0.1";
}