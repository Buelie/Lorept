import sys
import eel
import random
@eel.expose
def ren():
	a = ['您知道吗?生成器可以加载资源包','您知道吗?生成器可以加载插件和扩展']
	b = random.choice(a)